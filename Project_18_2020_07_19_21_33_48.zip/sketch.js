var monkey, monkeyImage;
var ground, groundImage,invisibleGround;
 var obstaclesGroup,obstacleImage;
var bananaGroup, bananaImage;
var score = 0;

function spawnObstacles() {
  if(frameCount % 60 === 0) {
   
    var obstacle = createSprite(600,270,10,40);
    obstacle.velocityX = -6;
  obstacle.addImage("obstacle",obstacleImage);
  
    

    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.15;
    obstacle.lifetime = 100;
    obstaclesGroup.add(obstacle);
    
  }
  
}


function spawnbanana() {
  if(frameCount % 30 === 0) {
     var rand = random(190,230);
    var banana = createSprite(600,rand,10,40);
    banana.velocityX = -6;
  banana.addImage("banana",bananaImage); 
  
    switch(score){
      case 10:monkey.scale=0.12
        break;
      case 20:monkey.scale=0.14
        break;
        case 30:monkey.scale=0.16
        break;
        case 40:monkey.scale=0.18
        break;
        default:break;
      
           }

    //assign scale and lifetime to the obstacle           
    banana.scale = 0.05;
    banana.lifetime = 100;
    bananaGroup.add(banana);
    
  }
  
}


function preload(){
  monkeyImage=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaImage=loadImage("Banana.png");
  groundImage=loadImage("jungle.jpg");
  obstacleImage=loadImage("stone.png");
}


function setup() {
  createCanvas(600,300);
 
  ground = createSprite(400,-25,400,50);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  ground.velocityX=-5;
  ground.scale=2;

  bananaGroup = new Group();
  
  invisibleGround=createSprite(200,300,400,10);
  invisibleGround.visible=false;
  
  
  obstaclesGroup = new Group();
  
  monkey = createSprite(50,260,10,10);
monkey.addAnimation("monkey.png",monkeyImage);
  monkey.scale=0.10;
}


function draw(){
 background(255); 
  
    if(monkey.isTouching(bananaGroup)){
       bananaGroup.destroyEach();
       score=score+2;
      
       }
  if(obstaclesGroup.isTouching(monkey)){
     monkey.scale=0.10; 
     }
  
 
  monkey.velocityY=monkey.velocityY+0.8;
  if(keyDown("space")){
     monkey.velocityY=-12;
     }
  
  monkey.collide(invisibleGround);
  
  
   if (ground.x < 0){
    ground.x = ground.width/2;
  }
  spawnbanana()
  spawnObstacles();
  drawSprites();
   stroke("white");
  textSize(20);
  fill("white");
  
  text("score:" + score,500,52);
  
}